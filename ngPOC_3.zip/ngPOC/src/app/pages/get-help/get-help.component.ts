import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-help',
  templateUrl: './get-help.component.html',
  styleUrls: ['./get-help.component.scss']
})
export class GetHelpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
