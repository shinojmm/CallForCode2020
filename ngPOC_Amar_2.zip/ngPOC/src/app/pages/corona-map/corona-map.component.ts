import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corona-map',
  templateUrl: './corona-map.component.html',
  styleUrls: ['./corona-map.component.scss']
})
export class CoronaMapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
