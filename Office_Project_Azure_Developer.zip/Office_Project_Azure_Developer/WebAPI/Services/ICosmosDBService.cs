﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Services
{
   public interface ICosmosDBService
    {
        Task<IEnumerable<Customer>> GetAllCustomers();

        Task<Customer> GetItemAsync(string id);

        Task AddItemAsync(Customer customer);

        Task UpdateItemAsync(string id, Customer customer);

        Task DeleteItemAsync(string id);

        Task<IEnumerable<Customer>> SearchCustomers(string dob, string postCode);
    }
}
