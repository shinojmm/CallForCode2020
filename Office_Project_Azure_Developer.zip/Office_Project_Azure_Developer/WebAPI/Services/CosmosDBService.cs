﻿using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Services
{
    public class CosmosDBService : ICosmosDBService
    {
        private Container _container;
        private Container _containerCustomerCopy;

        public CosmosDBService(CosmosClient cosmosClient, string dbName, string containerName)
        {
            _container = cosmosClient.GetContainer(dbName, containerName);
            _containerCustomerCopy = cosmosClient.GetContainer(dbName, "CustomerCopy");
        }

        public async Task AddItemAsync(Customer customer)
        {
            await _container.CreateItemAsync<Customer>(customer, new PartitionKey(customer.Id));
        }

        public async Task DeleteItemAsync(string id)
        {
            Customer item = await this.GetItemAsync(id);
            item.ttl = 5;
            await _container.UpsertItemAsync<Customer>(item, new PartitionKey(id));
            //await _container.DeleteItemAsync<Customer>(id, new PartitionKey(id));
        }

        public async Task<Customer> GetItemAsync(string id)
        {
            ItemResponse<Customer> response = await _container.ReadItemAsync<Customer>(id, new PartitionKey(id));
            return response.Resource;
        }

        public async Task<IEnumerable<Customer>> GetAllCustomers()
        {
            // Using Sql query statement
            var queryStatement = "select * from customer";
            var query = _container.GetItemQueryIterator<Customer>(new QueryDefinition(queryStatement));
            var results = new List<Customer>();

            while (query.HasMoreResults)
            {
                var queryResponse = await query.ReadNextAsync();
                results.AddRange(queryResponse.ToList());
            }

            return results;
        }

        public async Task<IEnumerable<Customer>> SearchCustomers(string dob, string postCode)
        {
            // Using Linq
            var queryable = _containerCustomerCopy.GetItemLinqQueryable<Customer>();
            var iterator = queryable.Where(p => p.PostCode == postCode && p.DOB == dob).ToFeedIterator();
            return await iterator.ReadNextAsync();
        }

        public async Task UpdateItemAsync(string id, Customer customer)
        {
            await _container.UpsertItemAsync<Customer>(customer, new PartitionKey(id));
        }
    }
}
