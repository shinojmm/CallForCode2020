﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class Customer
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }


        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }


        [JsonProperty(PropertyName = "dob")]
        public string DOB { get; set; }


        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }


        [JsonProperty(PropertyName = "address")]
        public string Address { get; set; }


        [JsonProperty(PropertyName = "postCode")]
        public string PostCode { get; set; }


        [JsonProperty(PropertyName = "ttl", NullValueHandling = NullValueHandling.Ignore)]
        public int? ttl { get; set; }
    }
}
