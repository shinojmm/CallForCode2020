﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Models;
using WebAPI.Services;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICosmosDBService _cosmosDBService;

        public CustomerController(ICosmosDBService cosmosDBService)
        {
            _cosmosDBService = cosmosDBService;
        }

        [HttpGet]
        public async Task<IEnumerable<Customer>> Get()
        {
            return await _cosmosDBService.GetAllCustomers();
        }

        [HttpGet("/Search")]
        public async Task<IEnumerable<Customer>> Search(string dob, string postCode)
        {
            return await _cosmosDBService.SearchCustomers(dob, postCode);
        }

        [HttpGet("{id}")]
        public async Task<Customer> Get(string id)
        {
            return await _cosmosDBService.GetItemAsync(id);
        }

        [HttpPost]
        public async Task Post([FromBody] CreateCustomerRequest request)
        {
            Customer customer = new Customer()
            {
                Id = Guid.NewGuid().ToString(),
                Name = request.Name,
                DOB = request.DOB,
                PhoneNumber = request.PhoneNumber,
                Address = request.Address,
                PostCode = request.PostCode
            };

            await _cosmosDBService.AddItemAsync(customer);
        }

        [HttpPut]
        public async Task Put([FromBody] Customer customer)
        {
            await _cosmosDBService.UpdateItemAsync(customer.Id, customer);
        }

        [HttpDelete("{id}")]
        public async Task Delete(string id)
        {
            await _cosmosDBService.DeleteItemAsync(id);
        }
    }
}
