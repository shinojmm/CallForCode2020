using System;
using System.Collections.Generic;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MyAzureFunction
{
    public static class FunctionChangeFeedReader
    {
        private const string CosmosEndpoint = "https://cosmosdb732593.documents.azure.com:443/";
        private const string CosmosMasterKey = "GalHBpXJIQgyBpYK3QHwoayzJprcYJM7M0UYJBBq6QxTZ2VgRLHYL07X2fjKHjdMJOSAKpC8GVLEN8TJFuiouw==";
        private static readonly DocumentClient _client;

        static FunctionChangeFeedReader()
        {
            _client = new DocumentClient(new Uri(CosmosEndpoint), CosmosMasterKey);
        }

        [FunctionName("FunctionChangeFeedReader")]
        public static void Run([CosmosDBTrigger(
            databaseName: "db732593",
            collectionName: "Customer",
            ConnectionStringSetting = "CosmosDbConnectionString",
            LeaseCollectionName = "leases", CreateLeaseCollectionIfNotExists = true)]IReadOnlyList<Document> input, ILogger log)
        {
            foreach (var inputItem in input)
            {
                var jDocument = JsonConvert.DeserializeObject<JObject>(inputItem.ToString());

                //if (jDocument["ttl"] == null || Convert.ToInt64(jDocument["ttl"]) >= 10)
                //{
                    var stateCollUri = UriFactory.CreateDocumentCollectionUri("db732593", "CustomerCopy");
                    _client.UpsertDocumentAsync(stateCollUri, inputItem).Wait();
                    log.LogInformation($"Upserted document id {inputItem.Id} in CustomerCopy collection");
                //}
                //else
                //{
                //    var stateDocUri = UriFactory.CreateDocumentUri("db732593", "CustomerCopy", inputItem.Id);
                //    _client.DeleteDocumentAsync(stateDocUri, new RequestOptions
                //    {
                //        PartitionKey = new PartitionKey(jDocument["dob"].Value<string>())
                //    }).Wait();
                //    log.LogInformation($"Deleted document id {inputItem.Id} in byState collection");
                //}
            }

        }
    }
}
